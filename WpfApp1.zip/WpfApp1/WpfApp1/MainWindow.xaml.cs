﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_24Oct18_PuneEntities dbContext = null;
        public MainWindow()
        {
            InitializeComponent();
            dbContext = new Training_24Oct18_PuneEntities();
        }
        public void PopulateUI()
        {
            //List<Product> prods= dbContext.Products.ToList();
            //var res= prods.OrderByDescending(s => s.Id);

            //dgProducts.ItemsSource = res;
            //cmbProdname.ItemsSource = res;
            //cmbProdname.DisplayMemberPath = "ProdName";

            List<Employee> emp = dbContext.Employees.ToList();
            dgProducts.ItemsSource = emp;
            cmbEmpName.ItemsSource = emp;
            cmbEmpName.DisplayMemberPath = "EmpName";


        }
        private void Window_Loaded(Object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            Employee emp = new Employee();
            emp.EmpName = cmbEmpName.Text;
            emp.EmpId = Convert.ToInt32(txtId.Text);
            emp.EmpDob = Convert.ToDateTime(dpDOB.Text);
            dbContext.Employees.Add(emp);
            dbContext.SaveChanges();
            MessageBox.Show("Inserted");
            PopulateUI();
        }
        int id;

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Employee emp = dbContext.Employees.Single(p => p.EmpId == id);
            emp.EmpName = cmbEmpName.Text;
            emp.EmpId = Convert.ToInt32(txtId.Text);
            emp.EmpDob = Convert.ToDateTime(dpDOB.Text);
            dbContext.SaveChanges();
            MessageBox.Show("UPDATED!!");
            PopulateUI();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {

        } 

        private void Editbtn_Click(object sender, RoutedEventArgs e)
        {
            id = ((Employee)cmbEmpName.SelectedItem).EmpId;
        }
    }
}
