﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Employee;
using EmployeeDetails.BussinessLayer;
using EmployeeDetails.ExceptionClass;

namespace LayeredArchiDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Employees employee = null;
        public MainWindow()
        {
            InitializeComponent();
        }
        private bool IsValid()
        {
            StringBuilder sb = new StringBuilder();

            bool isValid = true;
            if (txtEmpId.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Emp ID Required");
            }
            if (txtEmpName.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Employee Name Required");
            }
            if (dpEmpDob.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Date Required");
            }

            if (isValid == false)
            {
                throw new EmployeeClassException(sb.ToString());
            }

            return isValid;
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    employee = new Employees();
                    employee.EmpId = Convert.ToInt32(txtEmpId.Text);
                    employee.EmpName = txtEmpName.Text;
                    employee.EmpDate = Convert.ToDateTime(dpEmpDob.Text);
                    status = EmployeeBL.AddEmpBL(employee);
                    UpdateUI();
                }
                if (status == true)
                    MessageBox.Show("Inserted");

            }
            catch (EmployeeClassException ex)
            {
                MessageBox.Show(ex.Message);
            }



        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    employee = new Employees();
                    employee.EmpId = Convert.ToInt32(txtEmpId.Text);
                    employee.EmpName = txtEmpName.Text;
                    employee.EmpDate = Convert.ToDateTime(dpEmpDob.Text);
                    status = EmployeeBL.UpdateEmpBL(employee);
                    UpdateUI();
                }
                if(status == true)
                    MessageBox.Show("Updated");

            }
            catch (EmployeeClassException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    int id = Convert.ToInt32(txtEmpId.Text);
                    status = EmployeeBL.DeleteEmpBL(id);
                    UpdateUI();
                }
                if (status == true)
                    MessageBox.Show("Deleted");

            }
            catch (EmployeeClassException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void UpdateUI()
        {
            List<Employees> emplist = EmployeeBL.selectAllBL();
            dgEmpList.ItemsSource = emplist;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateUI();
        }
    }
}
