﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Question1
{
    class Program
    {
        static void Main(string[] args)
        {

            //readInFile();
          //  writeDataFromFile();
           copyFile();
            Console.ReadKey();
        }

        private static void writeDataFromFile()
        {
            string fileName, data;
            Console.WriteLine("Enter file name");
            fileName = Console.ReadLine();
            try
            {
                //write in a file.
                FileStream fileStream = new FileStream(fileName, FileMode.CreateNew, FileAccess.Write);
                StreamWriter streamWriter = new StreamWriter(fileStream);
                Console.WriteLine("Writing in a file....");
                Console.WriteLine("Write in a file...");
                data = Console.ReadLine();
                streamWriter.WriteLine(data);
                streamWriter.Flush();
                streamWriter.Close();
                fileStream.Close();
            }
            catch (IOException)
            {
                Console.WriteLine("File with given name is already exists.");
            }
        }

        private static void readInFile()
        {
            string fileName;
            Console.WriteLine("Enter file name");
            fileName = Console.ReadLine();

            try
            {
                //read from a file.
                FileStream file = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                StreamReader streamReader = new StreamReader(file);
                Console.WriteLine("Reading data from file......");
                int ch = streamReader.Read();

                while (ch > 0)
                {
                    Console.Write((char)ch);
                    ch = streamReader.Read();
                }
                streamReader.Read();
                streamReader.Close();
                file.Close();
                Console.WriteLine("Completed!!!");
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("File not found.");
            }
        }

        private static void copyFile()
        {
            string sourceAdd, destinationAdd;


            Console.WriteLine("Enter Source Address");
            sourceAdd = Console.ReadLine();
            Console.WriteLine("Enter Destination Adderss");
            destinationAdd = Console.ReadLine();

            // Use Path class to manipulate file and directory paths.
            //string sourceFile = System.IO.Path.Combine(sourceAdd, fileName);
            //string destFile = System.IO.Path.Combine(destinationAdd, fileName);
            File.Copy(sourceAdd, destinationAdd, true);

        }
    }
}
