﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CodefirstDemo
{
    class Employee_567 
    {
        [Key]
        public int EmpId{ get; set; }

        public string EmpName{ get; set; }

        public int DeptId { get; set; }

        public string city { get; set; }


    }
}
