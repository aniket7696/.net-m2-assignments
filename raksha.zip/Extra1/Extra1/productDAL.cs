﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace Extra1
{
    public class productDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;


        public productDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString); //cn1 is "connectionString" name decalred in App.config file.
        }

        public void Insert(Product objProd)
        {
            try
            {
                //cmd = new SqlCommand("insert into patilRaksha.Product values(@prodName,@price,@expdate)", cn);
                cmd = new SqlCommand("patilRaksha.USP_product1Insert", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure; //shows that cmd calls stored procedure
                cmd.Parameters.AddWithValue("@prodName", objProd.ProductName);
                cmd.Parameters.AddWithValue("@price", objProd.Price);
                cmd.Parameters.AddWithValue("@expdate", objProd.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();   //returns int(no. of rows affected)
            }
            catch (Exception ex1)
            {
                
            }
            finally
            {
                //to close connection
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }


        public void Update(Product objProd)
        {
            try
            {
                //cmd = new SqlCommand("insert into patilRaksha.Product values(@prodName,@price,@expdate)", cn)
                //cmd = new SqlCommand("update patilRaksha.Product set ProdName=@prodName, Price=@price, ExpDate=@expdate where Id=@id", cn);
                cmd = new SqlCommand("update patilRaksha.Product set ProductName=@prodName, Price=@price, ExpDate=@expdate where Id=@id", cn);
                cmd.Parameters.AddWithValue("@id", objProd.Id);
                cmd.Parameters.AddWithValue("@prodName", objProd.ProductName);
                cmd.Parameters.AddWithValue("@price", objProd.Price);
                cmd.Parameters.AddWithValue("@expdate", objProd.ExpDate);
                cn.Open();
                cmd.ExecuteNonQuery();   //returns int(no. of rows affected)
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            finally
            {
                //to close connection
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }


        public void Delete(Product objProd)
        {
            try
            {

                cmd = new SqlCommand("patilRaksha.USD_delete1", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", objProd.Id);
                
                cn.Open();
                cmd.ExecuteNonQuery();   //returns int(no. of rows affected)
            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            finally
            {
                //to close connection
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
        }
        public IEnumerable<Product> SelectAll()
        {
            List<Product> productlist = new List<Product>();
            try
            {
                cmd = new SqlCommand("select * from patilRaksha.Product", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Product p = new Product();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProductName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[2]);
                        p.ExpDate = Convert.ToDateTime(dr[3]);
                        productlist.Add(p);
                    }
                }
                dr.Close();
            }

            catch(Exception ex)
            {
                throw;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                {
                    cn.Close();
                }
            }
            return productlist;

        }
    }
}
