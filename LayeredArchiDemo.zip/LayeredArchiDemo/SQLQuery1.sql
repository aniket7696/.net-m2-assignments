﻿create table Vidya.Emp(
EmpId int primary key not null,
EmpName varchar(50),
EmpDob DateTime
);

create proc Vidya.USP_EmpDelete
@id int
as
	delete from Vidya.Emp where EmpId=@id;

create proc Vidya.USP_EmpUpdate
@id int,
@name varchar(50),
@dob datetime
as
	update Vidya.Emp set EmpName=@name, EmpDob=@dob where EmpId=@id;


create proc Vidya.USP_EmpInsert
@id int,
@name varchar(50),
@dob datetime
as
	insert into Vidya.Emp values(@id,@name,@dob)

select * from Vidya.Emp