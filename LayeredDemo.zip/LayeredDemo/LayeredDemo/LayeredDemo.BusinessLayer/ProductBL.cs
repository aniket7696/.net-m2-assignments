﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LayeredDemo.DataAccessLayer;
using LayeredDemo.Entitiy;
using LayeredDemo.Exceptions;

namespace LayeredDemo.BusinessLayer
{
    public class ProductBL
    {
        private static bool ValidateProd(Product product)
        {
            StringBuilder sb = new StringBuilder();

            bool validProd = true;

            if (product.ProductName==string.Empty)
            {
                validProd = false;
                sb.Append(Environment.NewLine + "Enter valid EmpID");
            }
           
            if (product.ExpDate.ToString().Length < 0)
            {
                validProd = false;
                sb.Append(Environment.NewLine + "Enter valid Date");
            }

            if (product.Price.ToString().Length < 0)
            {
                validProd = false;
                sb.Append(Environment.NewLine + "Enter valid Date");
            }

            if (validProd == false)
            {
                throw new UDExceptions(sb.ToString());
            }

            return validProd;
        }

        public static List<Product> GetAllProdBL()
        {
            List<Product> prodList = null;
            try
            {
                ProductDAL prodDAL = new ProductDAL();
                prodList = prodDAL.SelectAll();
            }
            catch (UDExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return prodList;
        }

        public static bool AddProdBL(Product product)
        {
            bool prodAdded = false;

            try
            {
                if (ValidateProd(product))
                {
                    ProductDAL prodDAL = new ProductDAL();
                    prodAdded = prodDAL.Insert(product);
                }
            }
            catch (UDExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return prodAdded;
        }

        public static bool UpdateProdBL(Product product)
        {
            bool prodUpdated = false;

            try
            {
                if (ValidateProd(product))
                {
                    ProductDAL prodDAL = new ProductDAL();
                    prodUpdated = prodDAL.Update(product);
                }
            }
            catch (UDExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return prodUpdated;
        }

        public static bool DeleteProdBL(Product product)
        {
            bool prodDeleted = false;

            try
            {
               
                    ProductDAL prodDAL = new ProductDAL();
                    prodDeleted = prodDAL.Delete(product);

                
               
            }
            catch (UDExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return prodDeleted;
        }

        public static List<Product> selectAllBL()
        {
            List<Product> prodList = null;
            try
            {
                ProductDAL prodDAL = new ProductDAL();
                prodList = prodDAL.SelectAll();
            }
            catch (UDExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return prodList;

        }
    }
}
