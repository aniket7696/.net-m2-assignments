﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Naukri.com_BL;
using Naukri.com_DAL;
using Naukri.com_Entitties;
using Naukri.com_Exceptions;

namespace Naukri.com_Presentation
{
    class Program
    {
        static void Main(string[] args)
        {
           
            
            int choice;
            char flag;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddGuest();
                        break;
                    case 2:
                        ListAllGuests();
                        break;
                    case 3:
                        SearchGuestByCity();
                        break;
                 
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("Do you want to continue Press Y to continue or any othe button to stop");
                flag = Convert.ToChar(Console.ReadLine());
            } while (flag=='Y'|| flag=='y');
            Naukri.com_DAL.NaukriDAL.SerializeData();
            Naukri.com_DAL.NaukriDAL.DeserializeData();
            Console.ReadLine();
        }

         private static void PrintMenu()
         {
            Console.WriteLine("\n***********Guest PhoneBook Menu***********");
            Console.WriteLine("1. Add Guest");
            Console.WriteLine("2. List All Guests");
            Console.WriteLine("3. Search Guest by City");
            Console.WriteLine("******************************************\n");

         }

         private static void AddGuest()
         {
            try
            {
                NaukriEntities naukriEntities = new NaukriEntities();
                Console.WriteLine("Enter Name:");
                naukriEntities.Name = Console.ReadLine();
                Console.WriteLine("Enter Qualification:");
                naukriEntities.Qualification = Console.ReadLine();
                Console.WriteLine("Enter Mobile No:");
                naukriEntities.COntactNo = Console.ReadLine();
                Console.WriteLine("Enter city:");
                naukriEntities.City = Console.ReadLine();
                Console.WriteLine("Enter Date of Birth in DD-MM-YYYY:");
                naukriEntities.DOB = Console.ReadLine();

                bool naukriAdded = NaukriBL.AddNaukritBL(naukriEntities);
                if(naukriAdded)
                {
                    Console.WriteLine("Naukri Added");
                }
                else
                {
                    Console.WriteLine("Naukri not added");
                }


            }
            catch (NaukriExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
         }

        private static void ListAllGuests()
        {
            try
            {
               List<NaukriEntities> naukriList = NaukriBL.GetAllNaukris();
                    if(naukriList!=null)
                    {
                        Console.WriteLine("******************************************************************************");
                        Console.WriteLine("Name\t\tQualification\t\tMobile\t\tCity\t\tDOB");
                        Console.WriteLine("******************************************************************************");
                        foreach(NaukriEntities naukri in naukriList)
                        {
                            Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}",naukri.Name,naukri.Qualification,naukri.COntactNo,naukri.City,naukri.DOB);
                        }
                        Console.WriteLine("******************************************************************************");
                    }

                
                   else
                   {
                        Console.WriteLine("No Naukris Available");
                   }
            }
            catch (NaukriExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchGuestByCity()
        {
            try
            {
                string searchCity;
                Console.WriteLine("Enter City to search");
                searchCity = Console.ReadLine();
                List< NaukriEntities> searchNaukri = NaukriBL.SearchCityBL(searchCity);
               
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Name\t\tQualification\t\tMobile No:\t\tCity\t\tDOB");
                    Console.WriteLine("******************************************************************************");
                    foreach (NaukriEntities naukri in searchNaukri)
                    {
                        Console.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}", naukri.Name, naukri.Qualification, naukri.COntactNo, naukri.City, naukri.DOB);
                       
                    }
                    Console.WriteLine("******************************************************************************");
                
              


            }
            catch (NaukriExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

     

    }
}
