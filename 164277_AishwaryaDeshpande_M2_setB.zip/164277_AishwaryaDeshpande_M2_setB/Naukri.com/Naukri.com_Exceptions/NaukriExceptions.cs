﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Naukri.com_Exceptions
{
    public class NaukriExceptions : ApplicationException
    {
       public NaukriExceptions():base()
        {

        }

        public NaukriExceptions(string message)
            : base(message)
        {
        }
        public NaukriExceptions(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }
}

