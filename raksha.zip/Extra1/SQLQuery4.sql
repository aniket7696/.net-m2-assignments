﻿CREATE PROC USD_delete
@id int
as
begin
delete from patilRaksha.Product where Id=@id
end