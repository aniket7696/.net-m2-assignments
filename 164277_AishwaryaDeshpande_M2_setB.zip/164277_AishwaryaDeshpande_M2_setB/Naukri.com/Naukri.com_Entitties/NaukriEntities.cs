﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Naukri.com_Entitties
{
    [Serializable]
    public class NaukriEntities
    {
       
        private string _name;
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        private string _qualification;
        public string Qualification
        {
            get
            {
                return _qualification;
            }
            set
            {
                _qualification = value;
            }
        }

        private string _contactNo;
        public string COntactNo
        {
            get
            {
                return _contactNo;
            }
            set
            {
                _contactNo = value;
            }
        }

        private string _city;
        public string City
        {
            get
            {
                return _city;
            }
            set
            {
                _city = value;
            }
        }

        private string _dob;
        public string DOB
        {
            get
            {
                return _dob;
            }
            set
            {
                _dob = value;
            }
        }

        public NaukriEntities()
        {
            _name = string.Empty;
            _qualification = string.Empty;
            _contactNo = string.Empty;
            _city = string.Empty;
            _dob = string.Empty;

        }

    }
}
