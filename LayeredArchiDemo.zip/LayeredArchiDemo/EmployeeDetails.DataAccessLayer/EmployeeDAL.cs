﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using Employee;
using EmployeeDetails.ExceptionClass;

namespace EmployeeDetails.DataAccessLayer
{
    public class EmployeeDAL
    {
        SqlConnection conn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public EmployeeDAL()
        {
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["conn1"].ConnectionString);
        }

        public bool InsertDAL(Employees emp)
        {
            bool empAdded = false;
            try
            {
                cmd = new SqlCommand("Vidya.USP_EmpInsert", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", emp.EmpId);
                cmd.Parameters.AddWithValue("@name", emp.EmpName);
                cmd.Parameters.AddWithValue("@dob", emp.EmpDate);
                conn.Open();
                int row=cmd.ExecuteNonQuery();
                if (row > 0)
                    empAdded = true;
            }
            catch (Exception ex)
            {
                throw new EmployeeClassException(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return empAdded;
        }

        public bool UpdateDAL(Employees emp)
        {
            bool empUpdated = false;
            try
            {
                //cmd = new SqlCommand("update Vidya.Product set ProdName=@pName, Price=@price, ExpDate=@eDate where Id=@id", conn);
                cmd = new SqlCommand("Vidya.USP_EmpUpdate", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", emp.EmpId);
                cmd.Parameters.AddWithValue("@name", emp.EmpName);
                cmd.Parameters.AddWithValue("@dob", emp.EmpDate);
                conn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    empUpdated = true;
            }
            catch (Exception ex)
            {
                throw new EmployeeClassException(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return empUpdated;
        }

        //code for delete
        public bool DeleteDAL(int empId)
        {
            bool empDeleted = false;
            try
            {
                //cmd = new SqlCommand("update Vidya.Product set ProdName=@pName, Price=@price, ExpDate=@eDate where Id=@id", conn);
                cmd = new SqlCommand("Vidya.USP_EmpDelete", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", empId);
                conn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    empDeleted = true;
            }
            catch (Exception ex)
            {
                throw new EmployeeClassException(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }

            return empDeleted;
        }

        public List<Employees> SelectAllDAL()
        {
            List<Employees> empList = new List<Employees>();

            try
            {

                cmd = new SqlCommand("select * from Vidya.Emp", conn);
                conn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Employees emp = new Employees();
                        emp.EmpId = Convert.ToInt32(dr[0]);
                        emp.EmpName = dr[1].ToString();
                        emp.EmpDate = Convert.ToDateTime(dr[2]);
                        empList.Add(emp);

                    }
                }
                dr.Close();
            }
            catch (Exception ex)
            {
                throw new EmployeeClassException(ex.Message);
            }
            finally
            {
                if (conn.State == System.Data.ConnectionState.Open)
                    conn.Close();
            }
            return empList;
        }

    }
}
