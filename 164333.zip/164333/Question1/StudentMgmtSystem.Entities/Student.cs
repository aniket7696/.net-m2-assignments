﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentMgmtSystem.Entities
{
    public class Student
    {
        public int _id;
        public string _name, _courseName;
        public char _grade;

        public int Id
        {
            get
            {
                return _id;
            }
            set
            {
                value = _id;
            }
        }

        public string StudentName
        {
            get
            {
                return _name;
            }
            set
            {
                value = _name;
            }
        }

        public string CourseName
        {
            get
            {
                return _courseName;
            }
            set
            {
                value = _courseName;
            }
        }

        public char Grade
        {
            get
            {
                return _grade;
            }
            set
            {
                value = _grade;
            }
        }

    }
}
