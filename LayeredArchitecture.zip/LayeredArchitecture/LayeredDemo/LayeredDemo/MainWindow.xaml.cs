﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using StudentEntities;
using StudentExceptions;
using StudentDataAccessLayer;
using StudentBussinessLayer;

namespace LayeredDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Student student = null;
        public MainWindow()
        {
            InitializeComponent();
        }

        private bool IsValid()
        {
            StringBuilder sb = new StringBuilder();

            bool isValid = true;
            if (cmbName.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Student Name Required");
            }
            if (txtRollNo.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Student Roll No. Required");
            }
            if (dpDOJ.Text == string.Empty)
            {
                isValid = false;
                sb.Append(Environment.NewLine + "Date of Joining Required");
            }

            if (isValid == false)
            {
                throw new StudentException(sb.ToString());
            }

            return isValid;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateUI();
        }

        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    student = new Student();
                    student.RollNo = Convert.ToInt32(txtRollNo.Text);
                    student.StudentName = cmbName.Text;
                    student.DOJ= Convert.ToDateTime(dpDOJ.Text);
                    status = StudentBL.AddStudBL(student);
                    UpdateUI();
                }
                if (status == true)
                    MessageBox.Show("Inserted");

            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    student = new Student();
                    student.RollNo = Convert.ToInt32(txtRollNo.Text);
                    student.StudentName = cmbName.Text;
                    student.DOJ = Convert.ToDateTime(dpDOJ.Text);
                    status = StudentBL.UpdateStudBL(student);
                    UpdateUI();
                }
                if (status == true)
                    MessageBox.Show("Updated");

            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool status = false;
                if (IsValid())
                {
                    int RollNo = Convert.ToInt32(txtRollNo.Text);
                    status = StudentBL.DeleteStudBL(RollNo);
                    UpdateUI();
                }
                if (status == true)
                    MessageBox.Show("Deleted");

            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void UpdateUI()
        {
            List<Student> Studlist = StudentBL.selectAllBL();
            dgStudent.ItemsSource = Studlist;
        }
    }
}
