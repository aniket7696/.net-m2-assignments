﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Naukri.com_Entitties;
using Naukri.com_Exceptions;
using System.Data.Common;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
namespace Naukri.com_DAL
{
    public class NaukriDAL
    {
        public static List<NaukriEntities> naukriList = new List<NaukriEntities>();

        public bool AddNaukriDAL(NaukriEntities newNaukri)
        {
            bool naukriAdded = false;
            try
            {
                naukriList.Add(newNaukri);
                naukriAdded = true;
            }
            catch (SystemException ex)
            {
                throw new NaukriExceptions(ex.Message);
            }
            return naukriAdded;

        }

        public List<NaukriEntities> GetAllNaukrisDAL()
        {
            return naukriList;
        }


        public List<NaukriEntities> SearchNaukriDAL(string searchCity)
        {
            List<NaukriEntities> searchNaukri = new List<NaukriEntities>();
            try
            {
                searchNaukri.Add(naukriList.Find(naukri => naukri.City == searchCity));
            }
            catch (SystemException ex)
            {
                throw new NaukriExceptions(ex.Message);
            }
            return searchNaukri;
        }

        public static void SerializeData()
        {
            List<NaukriEntities> naukriEntities = new List<NaukriEntities>();
            try
            {

                NaukriEntities objContact = new NaukriEntities();
                //Console.WriteLine(" contact details");
                //Console.WriteLine("Enter Name:");
                objContact.Name = "Aish";
                //Console.WriteLine("Enter Contact Name:");
                objContact.City = "Mumbai";
                    //Console.WriteLine("Enter Contact No:");
                    objContact.Qualification = "BE";
                objContact.COntactNo = "8983627713";
                naukriEntities.Add(objContact);

                string fileName;
                Console.WriteLine("Enter File Location");
                fileName = Console.ReadLine();

                FileStream fileStream = new FileStream(fileName, FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, naukriEntities);
                fileStream.Close();
                Console.Write("Suceessful!!!!!!");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        public static void DeserializeData()
        {
            try
            {
                string fileName;
                Console.WriteLine("Enter File Location");
                fileName = Console.ReadLine();
                FileStream fileStream = new FileStream(fileName, FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                List<NaukriEntities> obj = (List<NaukriEntities>)binaryFormatter.Deserialize(fileStream);
                fileStream.Close();
                foreach (NaukriEntities c in obj)
                {
                    Console.WriteLine("Name"+c.Name+"Qualification:"+c.Qualification);
                }



            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
