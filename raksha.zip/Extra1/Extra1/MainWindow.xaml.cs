﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Extra1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        productDAL objdal = new productDAL();
        public MainWindow()
        {
            InitializeComponent();
        }


        public bool IsInputValid()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (cmbProdName.Text == null | cmbProdName.Text == string.Empty | cmbProdName.Text.Length < 1)
            {
                sb.Append("\nProduct-Name is Mandatory!");
                isValid = false;
            }
            if (cmbPrice.Text == null | cmbPrice.Text == string.Empty | cmbPrice.Text.Length < 1)
            {
                sb.Append("\nProduct-Price is Mandatory!");
                isValid = false;
            }
            if (datepickerexp.Text == null | datepickerexp.Text == string.Empty | datepickerexp.Text.Length < 1)
            {
                sb.Append("\nExpiry Date is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                Console.WriteLine("enter valid data");
                //throw new PMS_Exception(sb.ToString());
            }

            return isValid;
        }


        public void PopulateUI()
        {
            IEnumerable<Product> prod = objdal.SelectAll();
            dgname.ItemsSource = prod;
            cmbProdName.ItemsSource = prod;
            cmbProdName.DisplayMemberPath = "ProductName";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }



        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            if (IsInputValid())
            {

                Product p = new Product()
                {
                    ProductName = cmbProdName.Text,
                    Price = Convert.ToDecimal(cmbPrice.Text),
                    ExpDate = Convert.ToDateTime(datepickerexp.Text)

                };
                objdal.Insert(p);
                MessageBox.Show("Insert");
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (IsInputValid())
            {
                Product p = (Product)cmbProdName.SelectedItem;

                p.ProductName = cmbProdName.Text;
                p.Price = Convert.ToDecimal(cmbPrice.Text);
                p.ExpDate = Convert.ToDateTime(datepickerexp.Text);

                objdal.Update(p);
                MessageBox.Show("Update");
                // PopulateUI();
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (IsInputValid())
            {

                Product p = (Product)cmbProdName.SelectedItem;
                objdal.Delete(p);
                MessageBox.Show("Delete");
                PopulateUI();
            }
        }

        private void CmbProdName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Product p = (Product)cmbProdName.SelectedItem;
            //MessageBox.Show(p.Id.ToString());
        }
    }
}
