﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentMgmtSystem.Entities;
using StudentMgmtSystemExcption.Excption;

namespace StudentMgmtSystemDAL.DAL
{
    public class StudentDAL
    {
        public static List<Student> objStudentList = new List<Student>();

        public bool AddBookDAL(Student objStudent)
        {
            bool studentAdded = false;
            try
            {
                objStudentList.Add(objStudent);
                studentAdded = true;
            }
            catch (SystemException objEx)
            {
                throw new StudentException(objEx.Message);
            }
            return studentAdded;
        }


        public List<Student> GetAllBookDAL()
        {
            return objStudentList;
        }

        
    }
}
