﻿create table aish164277.Product277([Id] int Identity(1,1) Primary key not null ,[ProductName] varchar(20) null, [ExpDate] date null,[Price] decimal null);
create Proc aish164277.USP_InsertProducts123
@pname varchar(20),
@price decimal,
@expdate date
as
	insert into aish164277.Product277 values(@pname,@expdate,@price);

create proc aish164277.USP_UpdateProduct123
@pname varchar(20),
@price decimal,
@expdate date,
@id int
as
update aish164277.Product277 set  ProductName=@pname,ExpDate=@expdate,Price=@price where Id=@id;

create proc aish164277.USP_delProd123
@id int
as
delete from aish164277.Product277 where Id=@id

select * from aish164277.Product277;

insert into aish164277.Product277 values('CPU',getdate(),3000);

create proc aish164277.nextid 
 @max int,@next int out
as
select @max=max(id) from aish164277.Product277
select @next=@max+1 from aish164277.Product277
