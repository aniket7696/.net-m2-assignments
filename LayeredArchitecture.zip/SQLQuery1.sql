CREATE TABLE [ashriran].[ProductLayer](
[Id] int identity (1,1) primary key not null,
[ProductName] varchar(20) null,
[Price] decimal (18) null,
[ExpDate] date null);

select * from ashriran.ProductLayer

insert into ashriran.Products ([ProductName],[Price],[ExpDate]) values ('Table',100.00,'07/07/1969');


create proc ashriran.InsertProc 
@Name varchar(20),
@Price decimal(18),
@Date date
as insert into ashriran.Product values (@Name,@Price,@Date);

delete from ashriran.ProductLayer where Id=2;

