﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentMgmtSystem.Entities;
using StudentMgmtSystemBL.BL;
using StudentMgmtSystemDAL.DAL;
using StudentMgmtSystemExcption.Excption;

namespace StudentMgmtSystemPL.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            char choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Your Valuable Choice");
                int taskFlag;
                taskFlag = Convert.ToInt32(Console.ReadLine());
                switch (taskFlag)
                {
                    case 1:
                        // Calling Add Method
                        AddStudent();
                        break;
                    case 2:
                        //Calling List Method
                        ListStudent();
                        break;
                    
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
                Console.WriteLine("DO YOU WANT TO CONTINUE?? PRESS 'y' FOR YES AND 'n' FOR NO");
                choice = Convert.ToChar(Console.ReadLine());
            } while (choice == 'y' || choice == 'Y');
        }

        static void PrintMenu()
        {
            Console.WriteLine("Enter Your Choice \n");
            Console.WriteLine("1 for ADD ");
            Console.WriteLine("2 for List");
           

        }

        //Method to Add Student
        static void AddStudent()
        {
            try
            {
                Student objStudent = new Student();
                Console.WriteLine("Enter Student Details ");

                Console.WriteLine("Enter Student Id ");
                objStudent.Id = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Student Name ");
                objStudent.StudentName = Console.ReadLine();
                Console.WriteLine("Enter Course name: ");
                objStudent.CourseName= Console.ReadLine();
                Console.WriteLine("Enter Grade ");
                objStudent.Grade =Convert.ToChar( Console.ReadLine());

                bool studentAdded;
                studentAdded = StudentBL.AddStudentBL(objStudent);
                if (studentAdded)
                {
                    Console.WriteLine("student Added Successfully");
                }
                else
                {
                    Console.WriteLine("student Not Added!!! ");
                }
            }
            catch (StudentException objBukMgmtSystmEx)
            {
                Console.WriteLine(objBukMgmtSystmEx.Message);
            }

        }

        //Method to List all the Students
        static void ListStudent()
        {
            try
            {
                List<Student> objStudentList;
                objStudentList = StudentBL.GetAllStudentBL();
                if (objStudentList != null)
                {
                    Console.WriteLine("Book List");
                    foreach (Student objStudent in objStudentList)
                    {
                        Console.WriteLine("ID: " + objStudent.Id);
                        Console.WriteLine("Name: " + objStudent.StudentName);
                        Console.WriteLine("Course name: " + objStudent.CourseName);
                        Console.WriteLine("Grade: " + objStudent.Grade);
                       
                    }
                }
                else
                {
                    Console.WriteLine("Student Record is not present");
                }
            }
            catch (StudentException objBukMgmtSystmEx)
            {
                Console.WriteLine(objBukMgmtSystmEx.Message);
            }

        }












    }


    
    }

