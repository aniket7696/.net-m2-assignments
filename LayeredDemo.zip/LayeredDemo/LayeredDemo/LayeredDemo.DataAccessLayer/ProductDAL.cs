﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LayeredDemo.Entitiy;
using LayeredDemo.Exceptions;
using System.Data.SqlClient;
using System.Configuration;

namespace LayeredDemo.DataAccessLayer
{
    public class ProductDAL
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;

        public ProductDAL()
        {
            cn = new SqlConnection(ConfigurationManager.ConnectionStrings["cn1"].ConnectionString);
        }
        public bool Insert(Product product)
        {
            bool prodAdded = false;
            try
            {
                //cmd = new SqlCommand(" insert into [aish164277].[Product] values(@pname,@expdate,@price)", cn);
                cmd = new SqlCommand("aish164277.USP_InsertProducts123", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pname", product.ProductName);
                cmd.Parameters.AddWithValue("@expdate", product.ExpDate);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    prodAdded = true;

            }
            catch (Exception ex1)
            {
                throw ex1;
            }
            finally
            {
                //to close connection
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();

            }
            return prodAdded;

        }

        public bool Update(Product product)
        {
            bool prodUpdated = false;
            try
            {
                //cmd = new SqlCommand("update aish164277.Product set ProductName=@pname,ExpDate=@expdate,Price=@price where Id=@id", cn);
                cmd = new SqlCommand("aish164277.USP_UpdateProduct123", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);
                cmd.Parameters.AddWithValue("@pname", product.ProductName);
                cmd.Parameters.AddWithValue("@expdate", product.ExpDate);
                cmd.Parameters.AddWithValue("@price", product.Price);
                cn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    prodUpdated = true;
            }
            catch(UDExceptions ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return prodUpdated;
        }

        public bool Delete(Product product)
        {
            bool prodDeleted = false;
            try
            {
                cmd = new SqlCommand("aish164277.USP_delProd123", cn);
                //cmd = new SqlCommand("aish164277.USP_UpdateProduct1", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", product.Id);

                cn.Open();
                int row = cmd.ExecuteNonQuery();
                if (row > 0)
                    prodDeleted = true;
            }
            catch(UDExceptions ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return prodDeleted;
        }

        public List<Product> SelectAll()
        {
            List<Product> products = new List<Product>();
            try
            {
                cmd = new SqlCommand("select * from aish164277.Product277", cn);
                cn.Open();
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        Product p = new Product();
                        p.Id = Convert.ToInt32(dr[0]);
                        p.ProductName = dr[1].ToString();
                        p.Price = Convert.ToDecimal(dr[3]);
                        p.ExpDate = Convert.ToDateTime(dr[2]);
                        products.Add(p);
                    }
                }
                dr.Close();
            }
            catch (UDExceptions ex1)
            {
                throw ex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (cn.State == System.Data.ConnectionState.Open)
                    cn.Close();
            }
            return products;
        }

      
    }
}
