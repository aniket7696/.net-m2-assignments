﻿///<summary>
///Author Name          : Aniket Shrirang
///Desc                 : Creating File at specific path and getting its details
///Version              : 1.0
///Last Modified Date   : 05-Dec-2018
///Change Description   : No change
///</summary> 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace File
{
    class Program
    {
        static void Main(string[] args)
        {
            //WriteDataInFile();
            ReadFromFile();
            Console.ReadKey();
        }

        private static void WriteDataInFile()
        {
            string fileName, data;
            Console.WriteLine("Enter file name");
            fileName = Console.ReadLine();
            Console.WriteLine("Please pass the Path of file");
            string path = Console.ReadLine();
            FileInfo fileObj = new FileInfo(@path);
            try
            {
                //writing Data in a file.
                FileStream fileStream = new FileStream(fileName, FileMode.CreateNew, FileAccess.Write);
                StreamWriter streamWriter = new StreamWriter(fileStream);
                Console.WriteLine("Writing in a file....");
                data = Console.ReadLine();
                streamWriter.WriteLine(data);
                streamWriter.Flush();
                streamWriter.Close();
                fileStream.Close();
            }
            catch (IOException)
            {
                Console.WriteLine("File with given name is already exists.");
            }
        }

        private static void ReadFromFile()
        {
            string fileName;
            Console.WriteLine("Enter file name");
            fileName = Console.ReadLine();
            Console.WriteLine("Please pass the Path of file");
            string path = Console.ReadLine();
            FileInfo fileObj = new FileInfo(@path);

            try
            {
                //cheks if fileObj is present or not
                if (fileObj.Exists)
                {
                    Console.WriteLine("File Name = {0}", fileObj.Name);
                    Console.WriteLine("File length in Bytes = {0}", fileObj.Length);
                    Console.WriteLine("File Extension = {0}", fileObj.Extension);
                    Console.WriteLine("File Full path = {0}", fileObj.FullName);
                    Console.WriteLine("File Directory = {0}", fileObj.DirectoryName);
                    Console.WriteLine("File Parent Directory = {0}", fileObj.Directory);
                    Console.WriteLine("File Creation Date and Time = {0}", fileObj.CreationTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Modified Date and Time = {0}", fileObj.LastWriteTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Last Access Date and Time = {0}", fileObj.LastAccessTime.ToString("dd-MM-yyyy hh:mm:ss tt"));
                    Console.WriteLine("File Attributes = {0}", fileObj.Attributes.ToString());
                }
                else
                {
                    Console.WriteLine("File does not Exists");
                }
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("File not found.");
            }
        }
    }
}
