﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentMgmtSystem.Entities;
using StudentMgmtSystemDAL.DAL;
using StudentMgmtSystemExcption.Excption;

namespace StudentMgmtSystemBL.BL
{
    public class StudentBL
    {

        //Doing Validatioon
        public static bool ValidateStudent(Student objStudent)
        {

            StringBuilder objSB = new StringBuilder();
            bool validStudent = true;
            if (objStudent.Id.ToString().Length < 6 || objStudent.Id.ToString().Length > 6)
            {
                validStudent = false;
                objSB.Append(Environment.NewLine + "Student id must be of 6 digit");

            }
          
            if (objStudent.CourseName == string.Empty)
            {
                objStudent.CourseName = "Computer";
            }

            if(objStudent.Grade !='A'|| objStudent.Grade != 'B'|| objStudent.Grade != 'C'|| objStudent.Grade != 'F')
            {
                validStudent = false;
                objSB.Append(Environment.NewLine + " Enter valid grade from A,B,C OR F");
            }


            if (validStudent == false)
            {
                throw new StudentException(objSB.ToString());
            }

            return validStudent;

        }


        public static bool AddStudentBL(Student objStudent)
        {
            bool studentAdded = false;
            try
            {
                if (ValidateStudent(objStudent))
                {
                    StudentDAL objBookDAL = new StudentDAL();
                    studentAdded = objBookDAL.AddBookDAL(objStudent);
                }

            }
            catch (StudentException objstudentMgmtEx)
            {
                throw objstudentMgmtEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return studentAdded;

        }

        public static List<Student> GetAllStudentBL()
        {
            List<Student> objStudentList;
            try
            {
                StudentDAL objStudentDAL = new StudentDAL();
                objStudentList = objStudentDAL.GetAllBookDAL();

            }
            catch (StudentException objStudentMgmtEx)
            {
                throw objStudentMgmtEx;
            }
            catch (Exception objEx)
            {
                throw objEx;
            }
            return objStudentList;

        }
    }
}
