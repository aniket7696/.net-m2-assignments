﻿create procedure USP_update 

as

CREATE PROCEDURE USD_update1
       @prodname varchar(20),
       @price decimal,
	   @exp datetime
AS
      UPDATE patilRaksha.Product set ProductName=@prodname,Price=@price,ExpDate=@exp from patilRaksha.Product
                      